import random
#1. 
def count_sumten(list):
    count=0
    length = len(list)
    for i in range(length):
        for j in range(i+1, length):
            if list[i] + list[j]==10:
                count+=1
    return count
#2.
def find_range(numbers):
    if len(numbers) < 3:
        return "range determination not possible"
    maximum = numbers[0]
    minimum = numbers[0]
    for number in numbers:
        if number > maximum:
            maximum = number
        if number < minimum:
            minimum = number
    return maximum - minimum
#3.
def square_matrix(n):
    matrix = []
    number = 1
    for i in range(n):
        row = []
        for j in range(n):
            row.append(number)
            number += 1
        matrix.append(row)
    return matrix

#4.
def highest_character(text):
    text = text.upper()
    max_char = ""
    max_count = 0
    for ch in text:
        if ch.isalpha():
            count = 0
            for c in text:
                if c == ch:
                    count = count+1
            if count > max_count:
                max_count = count
                max_char = ch
    return max_char, max_count
#5.
def mean_median_mode(numbers):

    total = 0
    for i in numbers:
        total = total + i
    mean = total / len(numbers)

    numbers.sort()
    middle = len(numbers)//2
    median = numbers[middle]

    mode = numbers[0]
    max_count = 0
    for i in numbers:
        count = 0
        for j in numbers:
            if j == i:
                count = count + 1
        if count > max_count:
            max_count = count
            mode = i
    return mean,median,mode
    
def main():
    #1.
    list = [2,7,4,1,3,6]
    pair_count = count_sumten(list)
    print("list:",list)
    print("no. of pairs with sum 10: ",pair_count)
    #2.
    numbers = [5,3,8,1,0,4]
    range_value = find_range(numbers)
    print("range of the list: ", range_value)
    #3.
    size = int(input("Enter size of square matrix: "))
    matrix = square_matrix(size)
    print("Square Matrix:")
    for row in matrix:
        print(row)
    #4.
    text = input("enter a string: ")
    char, count = highest_character(text)
    print("highest occurring character: ",char)
    print("occurrence count: ",count)
    #5.
    numbers = []
    for i in range(25):
        num = random.randint(1,10)
        numbers.append(num)
    print("generated numbers:",numbers)
    mean,median,mode = mean_median_mode(numbers)
    print("mean: ",mean)
    print("median: ",median)
    print("mode: ",mode)
main()
