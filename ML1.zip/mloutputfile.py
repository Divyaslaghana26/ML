Python 3.13.5 (tags/v3.13.5:6cb20a2, Jun 11 2025, 16:15:46) [MSC v.1943 64 bit (AMD64)] on win32
Enter "help" below or click "Help" above for more information.
>>> 
=========== RESTART: C:\Users\Divya Rangumudri\Downloads\mlassign1.py ==========
list: [2, 7, 4, 1, 3, 6]
no. of pairs with sum 10:  2
range of the list:  8
Enter order: 2
Enter element: 3
Enter element: 4
Enter element: 5
Enter element: 6
Enter power: 4
[2461, 3060]
[3825, 4756]
enter a string: divyaslaghana
highest occurring character:  A
occurrence count:  4
generated numbers: [7, 4, 7, 10, 8, 3, 10, 9, 1, 10, 3, 5, 7, 3, 1, 1, 5, 4, 9, 3, 3, 8, 4, 1, 4]
mean:  5.2
median:  4
mode:  3
