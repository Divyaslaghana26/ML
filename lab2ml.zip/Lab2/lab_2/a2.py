import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report
def load_purchase_data(file_path):
    df = pd.read_excel(file_path, sheet_name="Purchase data")
    return df
def label_customers(df):
    df["Class"] = df["Payment (Rs)"].apply(lambda x: 1 if x > 200 else 0)
    return df
def split_features_labels(df):
    X = df[["Candies (#)", "Mangoes (Kg)", "Milk Packets (#)"]]
    y = df["Class"]
    return X, y
def train_classifier(X, y):
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.3, random_state=42
    )
    model = LogisticRegression()
    model.fit(X_train, y_train)
    return model, X_test, y_test
def evaluate_model(model, X_test, y_test):
    predictions = model.predict(X_test)
    accuracy = accuracy_score(y_test, predictions)
    report = classification_report(y_test, predictions, zero_division=0)
    return accuracy, report
def main():
    file_path = r"C:\Users\Divya Rangumudri\Downloads\SEM-4\ML\Lab2.zip"

    df = load_purchase_data(file_path)
    df = label_customers(df)

    X, y = split_features_labels(df)
    model, X_test, y_test = train_classifier(X, y)

    accuracy, report = evaluate_model(model, X_test, y_test)

    print("\nCustomer Classification Completed")
    print("Class Label: 1 = RICH, 0 = POOR")

    print("\nALL CUSTOMERS CLASSIFIED:")
    print(df[["Candies (#)", "Mangoes (Kg)", "Milk Packets (#)", "Payment (Rs)", "Class"]])

    print("\nModel Accuracy:", accuracy)
    print("\nClassification Report:\n", report)

if __name__ == "__main__":
    main()
