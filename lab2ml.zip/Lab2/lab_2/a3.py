import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import time
def load_stock_data(file_path):
    return pd.read_excel(file_path, sheet_name="IRCTC Stock Price")
def numpy_mean_variance(data):
    return np.mean(data), np.var(data)
def manual_mean(data):
    if len(data) == 0:
        return None
    return sum(data) / len(data)
def manual_variance(data):
    if len(data) == 0:
        return None
    mean = manual_mean(data)
    return sum((x - mean) ** 2 for x in data) / len(data)
def measure_time(func, data):
    times = []
    for _ in range(10):
        start = time.time()
        func(data)
        times.append(time.time() - start)
    return sum(times) / len(times)
def wednesday_mean(df):
    wed_data = df[df["Day"] == "Wednesday"]["Price"]
    return manual_mean(wed_data)
def april_mean(df):
    apr_data = df[df["Month"] == "Apr"]["Price"]
    return manual_mean(apr_data)
def loss_probability(df):
    losses = list(filter(lambda x: x < 0, df["Chg%"]))
    return len(losses) / len(df)
def profit_probability_wednesday(df):
    wed_data = df[df["Day"] == "Wednesday"]
    if len(wed_data) == 0:
        return None
    return (wed_data["Chg%"] > 0).mean()
def conditional_profit_given_wed(df):
    wed_data = df[df["Day"] == "Wednesday"]
    if len(wed_data) == 0:
        return None
    profit_days = wed_data[wed_data["Chg%"] > 0]
    return len(profit_days) / len(wed_data)
def plot_scatter(df):
    plt.scatter(df["Day"], df["Chg%"])
    plt.xlabel("Day of Week")
    plt.ylabel("Change %")
    plt.title("Scatter Plot of Chg% vs Day")
    plt.show()
def main():
    file_path = r"C:\Users\kowsa\OneDrive\Desktop\ML\Lab_2\Copy of Lab Session Data.xlsx"

    df = load_stock_data(file_path)
    price_data = df["Price"]
    np_mean, np_var = numpy_mean_variance(price_data)
    man_mean = manual_mean(price_data)
    man_var = manual_variance(price_data)
    numpy_time = measure_time(np.mean, price_data)
    manual_time = measure_time(manual_mean, price_data)
    wed_mean = wednesday_mean(df)
    apr_mean = april_mean(df)
    loss_prob = loss_probability(df)
    wed_profit_prob = profit_probability_wednesday(df)
    cond_prob = conditional_profit_given_wed(df)

    print("\nA3 — IRCTC STOCK ANALYSIS")

    print("\nPopulation Mean (NumPy):", np_mean)
    print("Population Variance (NumPy):", np_var)

    print("\nManual Mean:", man_mean)
    print("Manual Variance:", man_var)

    print("\nExecution Time Comparison (10 runs avg)")
    print("NumPy Mean Time:", numpy_time)
    print("Manual Mean Time:", manual_time)

    print("\nWednesday Sample Mean:", wed_mean if wed_mean is not None else "No Wednesday Data")
    print("April Sample Mean:", apr_mean if apr_mean is not None else "No April Data")

    print("\nLoss Probability:", loss_prob)

    print("Profit Probability on Wednesday:", 
          wed_profit_prob if wed_profit_prob is not None else "No Wednesday Data")

    print("Conditional Probability (Profit | Wednesday):", 
          cond_prob if cond_prob is not None else "No Wednesday Data")

    plot_scatter(df)

if __name__ == "__main__":
    main()
