import pandas as pd
import numpy as np
def load_thyroid_data(file_path):
    return pd.read_excel(file_path, sheet_name="thyroid0387_UCI")
def identify_datatypes(df):
    return df.dtypes
def suggest_encoding(df):
    encoding = {}
    for col in df.columns:
        if df[col].dtype == "object":
            unique_vals = df[col].nunique()
            if unique_vals <= 5:
                encoding[col] = "Label Encoding (Ordinal)"
            else:
                encoding[col] = "One-Hot Encoding (Nominal)"
    return encoding
def numeric_ranges(df):
    ranges = {}
    for col in df.select_dtypes(include=np.number).columns:
        ranges[col] = (df[col].min(), df[col].max())
    return ranges
def missing_values(df):
    return df.isnull().sum()
def detect_outliers(df):
    outliers = {}
    for col in df.select_dtypes(include=np.number).columns:
        Q1 = df[col].quantile(0.25)
        Q3 = df[col].quantile(0.75)
        IQR = Q3 - Q1
        lower = Q1 - 1.5 * IQR
        upper = Q3 + 1.5 * IQR
        count = ((df[col] < lower) | (df[col] > upper)).sum()
        outliers[col] = count___
    return outliers
def numeric_statistics(df):
    stats = {}
    for col in df.select_dtypes(include=np.number).columns:
        stats[col] = {
            "Mean": df[col].mean(),
            "Variance": df[col].var(),
            "Std Dev": df[col].std()
        }
    return stats
def main():
    file_path = r"C:\Users\Divya Rangumudri\Downloads\SEM-4\ML\Lab2.zip"

    df = load_thyroid_data(file_path)

    datatypes = identify_datatypes(df)
    encoding = suggest_encoding(df)
    ranges = numeric_ranges(df)
    missing = missing_values(df)
    outliers = detect_outliers(df)
    stats = numeric_statistics(df)

    print("\nA4 — THYROID DATA EXPLORATION")

    print("\nATTRIBUTE DATA TYPES:")
    print(datatypes)

    print("\nSUGGESTED ENCODING SCHEME:")
    for k, v in encoding.items():
        print(k, "->", v)

    print("\nNUMERIC DATA RANGES:")
    for k, v in ranges.items():
        print(k, "-> Min:", v[0], "Max:", v[1])

    print("\nMISSING VALUES COUNT:")
    print(missing)

    print("\nOUTLIER COUNT PER NUMERIC ATTRIBUTE:")
    for k, v in outliers.items():
        print(k, "->", v)

    print("\nMEAN, VARIANCE & STANDARD DEVIATION:")
    for col, values in stats.items():
        print(col, "->", values)

if __name__ == "__main__":
    main()
