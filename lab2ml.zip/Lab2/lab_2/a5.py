import pandas as pd
import numpy as np

def load_thyroid_data(file_path):
    return pd.read_excel(file_path, sheet_name="thyroid0387_UCI")

def get_first_two_vectors(df):
    return df.iloc[0], df.iloc[1]

def is_binary(values):
    unique_vals = set(values)
    binary_sets = [
        {0, 1},
        {True, False},
        {"t", "f"},
        {"yes", "no"},
        {"Y", "N"}
    ]
    return any(unique_vals.issubset(bset) for bset in binary_sets)

def convert_to_binary(val):
    mapping = {
        "t": 1, "f": 0,
        "yes": 1, "no": 0,
        "Y": 1, "N": 0,
        True: 1, False: 0
    }
    return mapping.get(val, val)

def select_binary_attributes(v1, v2):
    binary_cols = []
    for col in v1.index:
        values = pd.Series([v1[col], v2[col]])
        if is_binary(values):
            binary_cols.append(col)

    b1 = v1[binary_cols].apply(convert_to_binary).astype(int)
    b2 = v2[binary_cols].apply(convert_to_binary).astype(int)

    return b1, b2, binary_cols

def compute_f_values(v1, v2):
    f11 = np.sum((v1 == 1) & (v2 == 1))
    f10 = np.sum((v1 == 1) & (v2 == 0))
    f01 = np.sum((v1 == 0) & (v2 == 1))
    f00 = np.sum((v1 == 0) & (v2 == 0))
    return f11, f10, f01, f00

def compute_jaccard(f11, f10, f01):
    denom = f11 + f10 + f01
    return f11 / denom if denom != 0 else None

def compute_smc(f11, f10, f01, f00):
    total = f11 + f10 + f01 + f00
    return (f11 + f00) / total if total != 0 else None

def main():
    file_path = r"C:\Users\kowsa\OneDrive\Desktop\ML\Lab_2\Copy of Lab Session Data.xlsx"

    df = load_thyroid_data(file_path)

    v1, v2 = get_first_two_vectors(df)

    bin_v1, bin_v2, binary_cols = select_binary_attributes(v1, v2)

    f11, f10, f01, f00 = compute_f_values(bin_v1.values, bin_v2.values)

    jc = compute_jaccard(f11, f10, f01)
    smc = compute_smc(f11, f10, f01, f00)

    print("\nA5 — SIMILARITY MEASURE (JC & SMC)")

    print("\nBinary Attributes Used:", binary_cols)

    print("\nFirst Vector (Binary):")
    print(bin_v1.values)

    print("\nSecond Vector (Binary):")
    print(bin_v2.values)

    print("\nf11:", f11)
    print("f10:", f10)
    print("f01:", f01)
    print("f00:", f00)

    print("\nJaccard Coefficient (JC):", jc)
    print("Simple Matching Coefficient (SMC):", smc)

    print("\nJudgement:")
    print("JC focuses only on positive matches")
    print("SMC considers both positive and negative matches")

if __name__ == "__main__":
    main()
