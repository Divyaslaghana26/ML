import pandas as pd
import numpy as np

def load_thyroid_data(file_path):
    return pd.read_excel(file_path, sheet_name="thyroid0387_UCI")

def detect_outliers(series):
    Q1 = series.quantile(0.25)
    Q3 = series.quantile(0.75)
    IQR = Q3 - Q1
    lower = Q1 - 1.5 * IQR
    upper = Q3 + 1.5 * IQR
    return ((series < lower) | (series > upper)).any()

def impute_numeric(series):
    if detect_outliers(series.dropna()):
        return series.fillna(series.median()), "Median"
    else:
        return series.fillna(series.mean()), "Mean"

def impute_categorical(series):
    return series.fillna(series.mode()[0]), "Mode"

def impute_missing_values(df):
    methods_used = {}

    for col in df.columns:
        if df[col].dtype in ["int64", "float64"]:
            df[col], method = impute_numeric(df[col])
        else:
            df[col], method = impute_categorical(df[col])

        methods_used[col] = method

    return df, methods_used

def main():
    file_path = r"C:\Users\Divya Rangumudri\Downloads\SEM-4\ML\Lab2.zip"

    df = load_thyroid_data(file_path)

    missing_before = df.isnull().sum()

    df_imputed, methods_used = impute_missing_values(df)

    missing_after = df_imputed.isnull().sum()

    print("\nA8 — DATA IMPUTATION RESULTS")

    print("\nMissing Values Before Imputation:")
    print(missing_before)

    print("\nImputation Method Used Per Column:")
    for col, method in methods_used.items():
        print(col, "->", method)

    print("\nMissing Values After Imputation:")
    print(missing_after)

if __name__ == "__main__":
    main()
